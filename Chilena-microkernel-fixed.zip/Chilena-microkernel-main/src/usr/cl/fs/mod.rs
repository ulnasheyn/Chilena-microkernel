//! fs — filesystem commands

pub mod ls;
pub mod cat;
pub mod write;
pub mod mkdir;
