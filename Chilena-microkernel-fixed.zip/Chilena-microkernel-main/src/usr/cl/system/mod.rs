//! system — system management commands

pub mod install;
pub mod reboot;
