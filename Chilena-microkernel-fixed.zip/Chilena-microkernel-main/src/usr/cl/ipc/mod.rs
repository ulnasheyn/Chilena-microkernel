//! ipc — inter-process communication commands

pub mod send;
pub mod recv;
