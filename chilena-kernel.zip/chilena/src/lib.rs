//! Chilena Kernel - Core Library
//!
//! Arsitektur:
//!   sys/  → layer kernel (hardware, interrupt, memory, proses)
//!   api/  → jembatan kernel ↔ userspace
//!   usr/  → program userspace bawaan

#![no_std]
#![cfg_attr(test, no_main)]
#![feature(abi_x86_interrupt)]
#![feature(alloc_error_handler)]
#![feature(custom_test_frameworks)]
#![test_runner(crate::test_runner)]
#![reexport_test_harness_main = "test_main"]

extern crate alloc;

// Ekspor subsistem kernel
#[macro_use]
pub mod sys;

// Ekspor API layer
#[macro_use]
pub mod api;

// Ekspor userspace layer
pub mod usr;

use bootloader::BootInfo;

/// Versi kernel Chilena
pub const VERSION: &str = env!("CARGO_PKG_VERSION");

/// Ukuran kernel di memori (4 MB)
pub const KERNEL_SIZE: usize = 4 << 20;

/// Inisialisasi semua subsistem kernel secara berurutan
pub fn init(boot_info: &'static BootInfo) {
    // Tahap 1: Hardware dasar
    sys::vga::init();
    sys::gdt::init();
    sys::idt::init();
    sys::pic::init(); // Aktifkan interrupt
    sys::serial::init();
    sys::keyboard::init();
    sys::clk::init();

    klog!("SYS Chilena v{}", VERSION);

    // Tahap 2: Memori & CPU info
    sys::mem::init(boot_info);
    sys::cpu::init();
    sys::acpi::init();

    klog!("RTC {}", sys::clk::date_string());
}

/// Loop halt — dipakai saat panic atau kernel berhenti
pub fn hlt_loop() -> ! {
    loop {
        x86_64::instructions::hlt();
    }
}

// ---------------------------------------------------------------------------
// Testing support
// ---------------------------------------------------------------------------

pub trait Testable {
    fn run(&self);
}

impl<T: Fn()> Testable for T {
    fn run(&self) {
        print!("test {} ... ", core::any::type_name::<T>());
        self();
        println!("ok");
    }
}

pub fn test_runner(tests: &[&dyn Testable]) {
    let n = tests.len();
    println!("\nrunning {} test{}", n, if n == 1 { "" } else { "s" });
    for test in tests {
        test.run();
    }
    exit_qemu(QemuExitCode::Success);
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
#[repr(u32)]
pub enum QemuExitCode {
    Success = 0x10,
    Failed  = 0x11,
}

pub fn exit_qemu(code: QemuExitCode) {
    use x86_64::instructions::port::Port;
    unsafe {
        let mut port = Port::new(0xF4);
        port.write(code as u32);
    }
}

#[allow(dead_code)]
#[alloc_error_handler]
fn on_alloc_error(layout: alloc::alloc::Layout) -> ! {
    panic!("alloc error: could not allocate {} bytes", layout.size());
}

#[cfg(test)]
use bootloader::entry_point;
#[cfg(test)]
use core::panic::PanicInfo;

#[cfg(test)]
entry_point!(test_kernel_main);

#[cfg(test)]
fn test_kernel_main(boot_info: &'static BootInfo) -> ! {
    init(boot_info);
    test_main();
    hlt_loop();
}

#[cfg(test)]
#[panic_handler]
fn panic(info: &PanicInfo) -> ! {
    println!("PANIC: {}", info);
    exit_qemu(QemuExitCode::Failed);
    hlt_loop();
}

#[test_case]
fn trivial_assertion() {
    assert_eq!(1, 1);
}
