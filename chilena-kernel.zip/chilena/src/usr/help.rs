//! help — tampilkan info singkat Chilena

pub fn run() {
    println!("Chilena Kernel v{}", crate::VERSION);
    println!("Kernel x86_64 minimalis berbasis Rust.");
}
