//! `sys` — Layer kernel Chilena
//!
//! Semua subsistem hardware dan OS berada di sini.
//! Userspace TIDAK boleh akses modul ini langsung — gunakan `api/`.

pub mod acpi;
pub mod clk;
pub mod console;
pub mod cpu;
pub mod fs;
pub mod gdt;
pub mod idt;
pub mod keyboard;
pub mod mem;
pub mod pic;
pub mod process;
pub mod serial;
pub mod syscall;
pub mod vga;

// ---------------------------------------------------------------------------
// Macro kernel logging — tersedia di seluruh crate
// ---------------------------------------------------------------------------

/// Cetak pesan kernel ke konsol (tanpa timestamp)
#[macro_export]
macro_rules! print {
    ($($arg:tt)*) => {
        $crate::sys::console::print_fmt(format_args!($($arg)*))
    };
}

#[macro_export]
macro_rules! println {
    () => ($crate::print!("\n"));
    ($($arg:tt)*) => ($crate::print!("{}\n", format_args!($($arg)*)));
}

/// Log dengan timestamp boot sejak kernel nyala
#[macro_export]
macro_rules! klog {
    ($($arg:tt)*) => {{
        if !cfg!(test) {
            let t = $crate::sys::clk::uptime_secs();
            $crate::sys::console::print_fmt(format_args!(
                "\x1b[32m[{:8.3}]\x1b[0m {}\n",
                t,
                format_args!($($arg)*)
            ));
        }
    }};
}

/// Pesan error kernel (merah)
#[macro_export]
macro_rules! kerror {
    ($($arg:tt)*) => {{
        $crate::sys::console::print_fmt(format_args!(
            "\x1b[31mError:\x1b[0m {}\n",
            format_args!($($arg)*)
        ));
    }};
}

/// Pesan peringatan kernel (kuning)
#[macro_export]
macro_rules! kwarn {
    ($($arg:tt)*) => {{
        $crate::sys::console::print_fmt(format_args!(
            "\x1b[33mWarn:\x1b[0m {}\n",
            format_args!($($arg)*)
        ));
    }};
}

/// Pesan debug kernel (biru) — hanya aktif saat debug build
#[macro_export]
macro_rules! kdebug {
    ($($arg:tt)*) => {{
        #[cfg(debug_assertions)]
        $crate::sys::console::print_fmt(format_args!(
            "\x1b[34mDebug:\x1b[0m {}\n",
            format_args!($($arg)*)
        ));
    }};
}
